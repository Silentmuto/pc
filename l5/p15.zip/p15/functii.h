#ifndef _FUNCTII_H
#define _FUNCTII_H

float f(float x);
float g(float x, float y);

#endif

#include <stdio.h>
#include "functii.h"

int main(void)
{
	int x, y, pas;

	scanf("%d%d", &y, &pas);

	for (x = 0; x <= 10; x += pas)
	{
		printf("f(%d) = %lf\n", x, f(x));
		printf("g(%d, %d) = %lf\n", x, y, g(x,y)); 
	}

	return 0;	
}

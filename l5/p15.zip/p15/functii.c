#include <math.h>

float f(float x)
{
	if (x <= 2)
	{
		return x*x + 3*x + 5;
	}
	else if (x < 8)
	{
		return 3 * x;
	}
	return exp(x) + 2;
}

float g(float x, float y)
{
	return 3 * x * x + sin(x) / pow(y, 1./4);
}
